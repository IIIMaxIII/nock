#!/usr/bin/env bash

# Log startup for debugging
echo "Script started $(date) by $(whoami)" >> /tmp/h-stats.log

# Read h-manifest.conf with correct path
SCRIPT_DIR=$(dirname "$(realpath "$0")")
MANIFEST_FILE="$SCRIPT_DIR/h-manifest.conf"
if [[ ! -f "$MANIFEST_FILE" ]]; then
  echo "Error: File $MANIFEST_FILE not found" > /tmp/h-stats-error.log
  CUSTOM_LOG_BASENAME="/var/log/miner/gpu/gpu"  # Fallback value
else
  . "$MANIFEST_FILE" 2>> /tmp/h-stats-error.log || echo "Error: Failed to read $MANIFEST_FILE" >> /tmp/h-stats-error.log
fi

# Form log file path
LOG_FILE="${CUSTOM_LOG_BASENAME}.log"

# Check if log file exists
if [[ ! -f "$LOG_FILE" ]]; then
  echo "Error: Log file $LOG_FILE not found" > /tmp/h-stats-error.log
  exit 1
fi

# Change log file permissions
chmod u+rw "$LOG_FILE" 2>/dev/null

# Parse hashrate from last 100 log lines
declare -a hs
while IFS= read -r line; do
  if [[ $line =~ [0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{6}Z\ +INFO\ +Card-([0-9]+)\ speed:\ +([0-9]+\.[0-9]+)\ p/s ]]; then
    card_num="${BASH_REMATCH[1]}"
    speed="${BASH_REMATCH[2]}"
    hs[$card_num]=$speed
    echo "Found hashrate for Card-$card_num: $speed p/s" >> /tmp/h-stats-output.log
  fi
done < <(tail -n 100 "$LOG_FILE")

# Check if we have data
if [ ${#hs[@]} -eq 0 ]; then
  hs_array="0"
  khs="0"
else
  hs_array=$(printf ",%s" "${hs[@]}" | sed 's/,,*/,/g')
  hs_array="[${hs_array#,}]"
  echo "Hashrate array: $hs_array" >> /tmp/h-stats-output.log
  # Calculate total hashrate with decimal numbers
  khs=$(printf "%.2f" "$(echo "${hs[@]}" | tr ' ' '+' | bc -l 2>/dev/null)" || echo "0")
  echo "Calculated hashrate: $khs p/s" >> /tmp/h-stats-output.log
fi

# Calculate uptime (using system time if no direct value in logs)
start_time=$(stat -c '%Y' "$LOG_FILE" 2>/dev/null || date +%s)
current_time=$(date +%s)
uptime=$((current_time - start_time))
echo "Calculated uptime: $uptime seconds" >> /tmp/h-stats-output.log

# Calculate number of accepted shares (based on Heartbeat success)
accepted=$(grep -c "Heartbeat success" "$LOG_FILE" 2>/dev/null || echo "0")
echo "Number of accepted shares (Heartbeat success): $accepted" >> /tmp/h-stats-output.log

# Form JSON output for Hive OS
stats="{\"hs\": $hs_array, \"hs_units\": \"p/s\", \"uptime\": $uptime, \"ar\": [$accepted, 0]}"
echo "Formed statistics: $stats" >> /tmp/h-stats-output.log

# Output two lines: total hashrate and JSON
echo "$khs"
echo "$stats"