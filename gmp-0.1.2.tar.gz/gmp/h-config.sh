#!/usr/bin/env bash
# This code is included in the /hive/bin/custom function

. h-manifest.conf

# Create directory if it doesn't exist
CONFIG_DIR=$(dirname "$CUSTOM_CONFIG_FILENAME")
[[ ! -d $CONFIG_DIR ]] && mkdir -p $CONFIG_DIR && echo -e "${YELLOW}Created directory: $CONFIG_DIR${NOCOLOR}" || echo -e "${YELLOW}Directory $CONFIG_DIR exists${NOCOLOR}"

# Extract parameters from CUSTOM_USER_CONFIG
if [[ -n $CUSTOM_USER_CONFIG && $CUSTOM_USER_CONFIG =~ --pubkey=([^[:space:]]+) ]]; then
  PUBKEY="${BASH_REMATCH[1]}"
else
  echo -e "${RED}Error: --pubkey is required in Extra config${NOCOLOR}"
  return 1
fi

if [[ -n $WORKER_NAME ]]; then
  NAME=$WORKER_NAME
elif [[ -n $CUSTOM_USER_CONFIG && $CUSTOM_USER_CONFIG =~ --name=([^[:space:]]+) ]]; then
  NAME="${BASH_REMATCH[1]}"
else
  NAME=$(hostname)
  echo -e "${YELLOW}NAME not specified, using $(hostname): $NAME${NOCOLOR}"
fi

# Ignore --threads-per-card if not specified
if [[ -n $CUSTOM_USER_CONFIG && $CUSTOM_USER_CONFIG =~ --threads-per-card=([^[:space:]]+) ]]; then
  THREADS_PER_CARD="${BASH_REMATCH[1]}"
  THREADS_PARAM="--threads-per-card=$THREADS_PER_CARD"
else
  THREADS_PARAM=""
  echo -e "${YELLOW}THREADS_PER_CARD not specified, parameter ignored${NOCOLOR}"
fi

# Build the command
if [[ -n $THREADS_PARAM ]]; then
  conf="./gpm --pubkey=$PUBKEY --name=$NAME $THREADS_PARAM"
else
  conf="./gpm --pubkey=$PUBKEY --name=$NAME"
fi

# Write to dummy.conf with explicit permission check
echo "$conf" > "$CUSTOM_CONFIG_FILENAME" 2>/dev/null
if [[ ! -f $CUSTOM_CONFIG_FILENAME ]]; then
  echo -e "${RED}Error: Failed to create file $CUSTOM_CONFIG_FILENAME, check permissions${NOCOLOR}"
  return 1
fi

echo -e "${YELLOW}DEBUG: conf=$conf${NOCOLOR}"