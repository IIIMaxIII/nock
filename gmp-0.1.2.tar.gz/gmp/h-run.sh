#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}CUSTOM_LOG_BASENAME is not set${NOCOLOR}" && exit 1

# Check if configuration file exists
if [[ ! -f $CUSTOM_CONFIG_FILENAME ]]; then
  echo -e "${RED}Error: Configuration file $CUSTOM_CONFIG_FILENAME not found${NOCOLOR}"
  exit 1
fi

# Read command from file
conf=$(cat $CUSTOM_CONFIG_FILENAME)

if [[ -z $conf ]]; then
  echo -e "${RED}Error: Configuration file $CUSTOM_CONFIG_FILENAME is empty${NOCOLOR}"
  exit 1
fi

# Create log directory if it doesn't exist
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# Run command with logging
echo -e "${YELLOW}DEBUG: Starting: $conf${NOCOLOR}"
$conf 2>&1 | tee $CUSTOM_LOG_BASENAME.log