####################################################################################
###
### golden-miner-pool-prover
###
####################################################################################
# Allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_USER_CONFIG CUSTOM_CONFIG_FILENAME

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_USER_CONFIG =      $CUSTOM_USER_CONFIG"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"


#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/golden-miner/h-manifest.conf

WALLET_ONLY="${CUSTOM_TEMPLATE%%.*}"
conf=""
conf=" --pubkey=$WALLET_ONLY --name=$WORKER_NAME"

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

#echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

