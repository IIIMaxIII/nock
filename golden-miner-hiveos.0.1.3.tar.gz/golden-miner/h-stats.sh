####################################################################################
###
### golden-miner
###
####################################################################################

#!/usr/bin/env bash

#######################
# MAIN script body
#######################

. /hive/miners/custom/golden-miner/h-manifest.conf
stats_raw=`cat $CUSTOM_LOG_BASENAME.log | grep -w "speed" | tail -n 1 `
echo "stats_raw: $stats_raw"

#Calculate miner log freshness

maxDelay=120
#time_now=`date +%s`
time_now=$(date -u +%s)  # UTC
echo "time_now : $time_now"
#datetime_rep=`echo $stats_raw | awk '{print $1}' | awk -F[ '{print $2}'`
datetime_rep=`echo $stats_raw | awk '{print $1}' | cut -d '.' -f1 | sed 's/T/ /; s/Z//'`

#time_rep=`date -d "$datetime_rep" +%s`
time_rep=$(date -u -d "$datetime_rep" +%s)  # UTC
diffTime=`echo $((time_now-time_rep)) | tr -d '-'`
#diffTime=$((time_now - time_rep))
echo "diffTime : $diffTime"
if [ "$diffTime" -lt "$maxDelay" ]; then
        total_hashrate=`echo $stats_raw | awk '{print $5}' | cut -d "." -f 1,2 --output-delimiter='' | sed 's/$/0/'`
        echo "total_hashrate : $total_hashrate"
#	if [[ $stats_raw == *"Ghash"* ]]; then
#		total_hashrate=$(($total_hashrate*1000))
#	fi

        #GPU Status
        gpu_stats=$(< $GPU_STATS_JSON)
        #echo "GPU_STATS_JSON: $GPU_STATS_JSON" >&2
        #cat "$GPU_STATS_JSON" >&2
        
        echo "GPU_STATS_JSON=$GPU_STATS_JSON" >&2
        ls -l "$GPU_STATS_JSON" >&2
        jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" >&2


        readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
        busids=(${gpu_stats[0]})
        brands=(${gpu_stats[1]})
        temps=(${gpu_stats[2]})
        fans=(${gpu_stats[3]})
        gpu_count=${#busids[@]}

        hash_arr=()
        busid_arr=()
        fan_arr=()
        temp_arr=()
        lines=()

        if [ $(gpu-detect NVIDIA) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect NVIDIA)
                BRAND_MINER="nvidia"
        elif [ $(gpu-detect AMD) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect AMD)
                BRAND_MINER="amd"
        fi
        total_hashrate_sum=0
        # Determine shift for integrated graphics
        [[ ${brands[0]} == 'cpu' ]] && internalCpuShift=1 || internalCpuShift=0
        
        for(( i=0; i < gpu_count; i++ )); do
                # Filter out integrated graphics (cpu)
                if [[ "${brands[i]}" == 'cpu' ]]; then
                    continue
                fi
                
                [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
                busid_arr+=($((16#${BASH_REMATCH[1]})))
                temp_arr+=(${temps[i]})
                fan_arr+=(${fans[i]})                
#                gpu_raw=`cat $CUSTOM_LOG_BASENAME.log | grep -w "Device #"$i | tail -n 1 `
#                gpu_raw=`grep -w "Card-$i speed" $CUSTOM_LOG_BASENAME.log | tail -n 1`
                # Calculate correct GPU index accounting for integrated graphics
                gpu_index_for_log=$i
                if [[ $internalCpuShift -eq 1 ]]; then
                    gpu_index_for_log=$((i - internalCpuShift))
                fi
                gpu_raw=$(grep -w "Card-$gpu_index_for_log speed" "$CUSTOM_LOG_BASENAME.log" | tail -n 1 | tr -d '\000')

                echo "gpu_raw : $gpu_raw"  
#                hashrate=`echo $gpu_raw | awk '{print $(NF-1)}' | cut -d "." -f 1,2 --output-delimiter='' | sed 's/$/0/'`
                hashrate=$(echo "$gpu_raw" | awk '{print $(NF-1)}' | tr -d '\000' | cut -d "." -f1,2 --output-delimiter='' | sed 's/$/0/')

                echo "hashrate: $hashrate"
                hash_arr+=($hashrate)		
                total_hashrate_sum=$((total_hashrate_sum + hashrate))
                echo "hash_arr : $hash_arr"
        done

        hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
        bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`
        fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
        temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

        uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_CONFIG_FILENAME` ))


        #Compile stats/khs
        stats=$(jq -nc \
                --argjson hs "$hash_json"\
                --arg ver "$CUSTOM_VERSION" \
                --arg ths "$total_hashrate" \
                --argjson bus_numbers "$bus_numbers" \
                --argjson fan "$fan_json" \
                --argjson temp "$temp_json" \
                --arg uptime "$uptime" \
                '{ hs: $hs, hs_units: "khs", algo : "nock", ver:$ver , $uptime, $bus_numbers, $temp, $fan}')
        #khs=$total_hashrate
        khs=$(echo "scale=2; $total_hashrate_sum/1000" | bc)
else
  khs=0
  stats="null"
fi

echo Debug info:
echo Log file : $CUSTOM_LOG_BASENAME.log
echo Time since last log entry : $diffTime
echo Raw stats : $stats_raw
echo KHS : $khs
echo Output : $stats

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
