#!/usr/bin/env bash

. h-manifest.conf

LOG_FILE="$CUSTOM_LOG_BASENAME.log"
GPU_LIST_FILE="/var/run/hive/nockminer_gpus.conf"
STATS_HELPER="/hive/miners/custom/nockminer/nockminer-stats.sh"
STATS_PIDFILE="/var/run/hive/nockminer_stats.pid"

echo "----------------------------------------------------------------------"
echo "NOCKminer (Original Golden Miner) - 100% to YOUR wallet"
echo "----------------------------------------------------------------------"

GPU_COUNT=$(nvidia-smi -L | wc -l)
if [[ $GPU_COUNT -eq 0 ]]; then
    echo -e "\e[31m[$(date +'%H:%M:%S')] [FATAL] No NVIDIA GPUs detected! Aborting...\e[0m"
    echo "Miner aborted: No NVIDIA GPUs were detected." > "$LOG_FILE"
    exit 1
fi

CONF_CONTENT=$(< ./$CUSTOM_NAME.conf)
GPU_ARG=$(echo "$CONF_CONTENT" | grep -oE -- '(--gpu|--g|-g|--devices|--d|-d)[= ]([0-9,]+)|(--gpu|--g|-g|--devices|--d|-d) ([0-9,]+)' | head -n1)
TS_ARG=$(echo "$CONF_CONTENT" | grep -oE -- '--ts[= ]*[0-9,-]+' | head -n1)
CLEAN_CONF="$CONF_CONTENT"
GPU_LIST=""
TASKSET_CPUS=""

if [[ -n "$GPU_ARG" ]]; then
    REQUESTED_GPUS_STR=$(echo "$GPU_ARG" | sed -E 's/(--gpu|--g|-g|--devices|--d|-d)[= ]*//')
    CLEAN_CONF=$(echo "$CLEAN_CONF" | sed -E 's/(--gpu|--g|-g|--devices|--d|-d)[= ]*[0-9,]+//g')

    VALIDATED_GPUS=""
    INVALID_GPUS_FOUND=false
    IFS=',' read -ra REQUESTED_GPUS_ARR <<< "$REQUESTED_GPUS_STR"

    for gpu_idx in "${REQUESTED_GPUS_ARR[@]}"; do
        if [[ ! "$gpu_idx" =~ ^[0-9]+$ ]] || [[ "$gpu_idx" -ge "$GPU_COUNT" ]]; then
            echo -e "\e[31m[$(date +'%H:%M:%S')] [ERROR] Invalid GPU index: $gpu_idx. Available: 0-$((GPU_COUNT-1))\e[0m"
            INVALID_GPUS_FOUND=true
        else
            [[ -z "$VALIDATED_GPUS" ]] && VALIDATED_GPUS="$gpu_idx" || VALIDATED_GPUS="$VALIDATED_GPUS,$gpu_idx"
        fi
    done

    if [[ "$INVALID_GPUS_FOUND" = true && -z "$VALIDATED_GPUS" ]]; then
        echo -e "\e[31m[$(date +'%H:%M:%S')] [FATAL] Invalid GPU selection. Aborting...\e[0m"
        exit 1
    fi
    GPU_LIST="$VALIDATED_GPUS"
    echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Using GPUs: $GPU_LIST\e[0m"
else
    GPU_LIST=$(seq -s, 0 $((GPU_COUNT - 1)))
    echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Using all GPUs: $GPU_LIST\e[0m"
fi

echo "$GPU_LIST" > "$GPU_LIST_FILE"

if [[ -n "$TS_ARG" ]]; then
    TASKSET_CPUS=$(echo "$TS_ARG" | sed -E 's/--ts[= ]*//')
    CLEAN_CONF=$(echo "$CLEAN_CONF" | sed -E 's/--ts[= ]*[0-9,-]+//g')
    echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Using CPU affinity: $TASKSET_CPUS\e[0m"
fi

USER_PUBKEY=$(echo "$CLEAN_CONF" | grep -oE -- '--pubkey[= ]*[^ ]+' | sed -E 's/--pubkey[= ]*//g' | head -n1)
if [[ -z "$USER_PUBKEY" ]]; then
    echo -e "\e[31m[$(date +'%H:%M:%S')] [ERROR] Missing --pubkey in config. Exiting.\e[0m"
    exit 1
fi

CLEAN_CONF=$(echo "$CLEAN_CONF" | sed -E 's/--pubkey[= ]*[^ ]+//g')

start_stats_helper() {
    [[ ! -x "$STATS_HELPER" ]] && return
    if [[ -f "$STATS_PIDFILE" ]] && kill -0 "$(cat "$STATS_PIDFILE")" 2>/dev/null; then
        return
    fi
    LOG_FILE="$LOG_FILE" GPU_LIST="$GPU_LIST" USER_PUBKEY="$USER_PUBKEY" "$STATS_HELPER" &
    echo $! > "$STATS_PIDFILE"
}

start_stats_helper

echo -e "\e[32m[$(date +'%H:%M:%S')] [INFO] Starting miner...\e[0m"

if [[ -n "$TASKSET_CPUS" ]]; then
    echo -e "\e[33m → taskset -c $TASKSET_CPUS CUDA_VISIBLE_DEVICES=$GPU_LIST ./nockminer --pubkey=$USER_PUBKEY $CLEAN_CONF\e[0m"
    export CUDA_VISIBLE_DEVICES="$GPU_LIST"
    exec taskset -c "$TASKSET_CPUS" ./nockminer --pubkey="$USER_PUBKEY" $CLEAN_CONF | tee -a "$LOG_FILE"
else
    echo -e "\e[33m → CUDA_VISIBLE_DEVICES=$GPU_LIST ./nockminer --pubkey=$USER_PUBKEY $CLEAN_CONF\e[0m"
    export CUDA_VISIBLE_DEVICES="$GPU_LIST"
    exec ./nockminer --pubkey="$USER_PUBKEY" $CLEAN_CONF | tee -a "$LOG_FILE"
fi
