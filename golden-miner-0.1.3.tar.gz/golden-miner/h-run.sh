####################################################################################
###
### golden-miner
###
####################################################################################

#!/usr/bin/env bash

# Set working directory more reliably
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || {
    echo "ERROR: Failed to change to script directory: $SCRIPT_DIR"
    exit 1
}

[ -t 1 ] && . colors

. h-manifest.conf

echo $CUSTOM_NAME
echo $CUSTOM_LOG_BASENAME
echo $CUSTOM_CONFIG_FILENAME

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

#cat "$CUSTOM_CONFIG_FILENAME"

# Stop previous watchdog if running
pkill -f "watchdog.sh" 2>/dev/null

# Start watchdog in background
echo "Starting watchdog in background..."
./watchdog.sh &
WATCHDOG_PID=$!
echo "Watchdog started with PID: $WATCHDOG_PID"

# Start miner
./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME) "$@" 2>&1 | tee "$CUSTOM_LOG_BASENAME.log"

# Stop watchdog when miner exits
echo "Stopping watchdog..."
kill $WATCHDOG_PID 2>/dev/null



