#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SCRIPT_DIR/h-manifest.conf"

BIN_PATH="$SCRIPT_DIR/golden-miner-pool-prover"
CONFIG_FILE="$CUSTOM_CONFIG_FILENAME"
LOG_FILE="${CUSTOM_LOG_BASENAME}.log"

[[ -x "$BIN_PATH" ]] || chmod +x "$BIN_PATH"
[[ -f "$CONFIG_FILE" ]] || {
  echo "ERROR: config file not found: $CONFIG_FILE" >&2
  exit 1
}

source "$CONFIG_FILE"

pubkey="${PUBKEY:-}"
rig_name="${RIG_NAME:-${WORKER_NAME:-}}"
label="${LABEL:-}"
local_ip="${LOCAL_IP:-}"
threads_per_card="${THREADS_PER_CARD:-}"
extra_args="${EXTRA_ARGS:-}"
extra_programs_raw="${EXTRA_PROGRAMS:-}"
devices="${DEVICES:-}"
devices_override=""
devices="${DEVICES:-}"

if [[ -z "$pubkey" ]]; then
  echo "ERROR: Pubkey is not configured. Check your flight sheet." >&2
  exit 1
fi

trim_whitespace() {
  local text="$1"
  text="${text#${text%%[!$'\t\n ']*}}"
  text="${text%${text##*[!$'\t\n ']}}"
  printf '%s' "$text"
}

extra_programs=()
if [[ -n "$extra_programs_raw" ]]; then
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    line=$(trim_whitespace "$line")
    [[ -z "$line" ]] && continue
    extra_programs+=("$line")
  done <<< "$(printf '%s\n' "$extra_programs_raw")"
fi

extra_program_pids=()
extra_program_temp_files=()
proxy_monitor_pid=""
proxy_health_interval=${PROXY_HEALTH_INTERVAL:-15}
proxy_health_timeout=${PROXY_HEALTH_TIMEOUT:-5}
proxy_health_failures=${PROXY_HEALTH_MAX_FAILURES:-3}
proxy_health_min_success=${PROXY_HEALTH_MIN_SUCCESS:-3}
pending_proxy_file="/tmp/goldenminer_pending_proxy"

cleanup() {
  if ((${#extra_program_pids[@]})); then
    for pid in "${extra_program_pids[@]}"; do
      if kill -0 "$pid" >/dev/null 2>&1; then
        kill "$pid" >/dev/null 2>&1 || true
        wait "$pid" 2>/dev/null || true
      fi
    done
  fi

  if ((${#extra_program_temp_files[@]})); then
    for cfg in "${extra_program_temp_files[@]}"; do
      [[ -n "$cfg" ]] && rm -f "$cfg" 2>/dev/null || true
    done
  fi

  stop_proxy_monitor
  rm -f "$pending_proxy_file" 2>/dev/null || true
}

trap cleanup EXIT

trigger_miner_restart() {
  echo "INFO: scheduling miner restart command" | tee -a "$LOG_FILE"
  if command -v miner >/dev/null 2>&1; then
    local delay=${MINER_RESTART_DELAY:-2}
    if setsid nohup bash -c "sleep $delay; miner restart" >>"$LOG_FILE" 2>&1 & then
      echo "INFO: miner restart command dispatched (delay ${delay}s)" | tee -a "$LOG_FILE"
    else
      echo "WARNING: failed to dispatch miner restart command" | tee -a "$LOG_FILE"
    fi
  else
    echo "WARNING: miner command not found in PATH; manual restart required" | tee -a "$LOG_FILE"
  fi
}

start_additional_program() {
  local entry="$1"
  local program_path="$entry"
  local program_config=""

  local separator=""
  if [[ "$program_path" == *'::'* ]]; then
    separator="::"
  elif [[ "$program_path" == *':'* ]]; then
    local candidate=${program_path#*:}
    candidate=$(trim_whitespace "$candidate")
    local cand_char=${candidate:0:1}
    if [[ $cand_char == '{' || $cand_char == '[' || $cand_char == '"' || $cand_char == "'" ]]; then
      separator=":"
    fi
  fi

  if [[ -n "$separator" ]]; then
    program_config=${program_path#*${separator}}
    program_path=${program_path%%${separator}*}
    program_path=$(trim_whitespace "$program_path")
    program_config=$(trim_whitespace "$program_config")

    if [[ ${#program_config} -ge 2 ]]; then
      local first_char=${program_config:0:1}
      local last_char=${program_config: -1}
      if [[ $first_char == $last_char && ( $first_char == '"' || $first_char == "'" ) ]]; then
        program_config=${program_config:1:${#program_config}-2}
      fi
      program_config=$(trim_whitespace "$program_config")
    fi
  fi

  if [[ -z "$program_path" ]]; then
    return
  fi

  if [[ ! -e "$program_path" ]]; then
    echo "WARNING: additional program not found: $program_path" >&2
    return
  fi

  if [[ -d "$program_path" ]]; then
    echo "WARNING: additional program path is a directory: $program_path" >&2
    return
  fi

  if [[ ! -x "$program_path" ]]; then
    if ! chmod +x "$program_path" 2>/dev/null; then
      echo "WARNING: unable to make additional program executable: $program_path" >&2
      return
    fi
  fi

  local program_args=()
  local run_desc="$program_path"
  local config_path=""
  local inline_file=""

  if [[ -n "$program_config" ]]; then
    if [[ -f "$program_config" ]]; then
      config_path="$program_config"
    elif [[ ${program_config:0:1} == '{' || ${program_config:0:1} == '[' ]]; then
      local program_dir
      program_dir=$(dirname "$program_path")
      inline_file="$program_dir/config.conf"
      if ! printf '%s\n' "$program_config" > "$inline_file"; then
        echo "WARNING: failed to write inline config for additional program: $inline_file" >&2
        inline_file=""
      else
        chmod 600 "$inline_file" 2>/dev/null || true
        config_path="$inline_file"
      fi
    else
      echo "WARNING: config file not found for additional program: $program_config" >&2
    fi
  fi

  if [[ -n "$config_path" ]]; then
    program_args+=("--config" "$config_path")
    run_desc+=" (config: $config_path)"
  fi

  echo "Starting additional program: $run_desc"
  if [[ -n "$config_path" ]]; then
    RUN_CONFIG_FILE="$config_path" "$program_path" "${program_args[@]}" &
  else
    "$program_path" "${program_args[@]}" &
  fi
  extra_program_pids+=($!)
}

nvtool_opts=()
nvtool_vals=()
miner_extra_args=()
proxy_endpoints=()

add_nvtool_cmd() {
  local opt="$1"
  local value="$2"

  if [[ -z $value ]]; then
    echo "WARNING: $opt requires a numeric value" >&2
    return
  fi

  if [[ ! $value =~ ^-?[0-9]+$ ]]; then
    echo "WARNING: ignoring $opt with non-numeric value '$value'" >&2
    return
  fi

  nvtool_opts+=("$opt")
  nvtool_vals+=("$value")
}

register_proxy_endpoint() {
  local raw="$1"
  if [[ -z "$raw" ]]; then
    return
  fi

  IFS=',' read -ra _proxy_parts <<< "$raw"
  for part in "${_proxy_parts[@]}"; do
    part=$(trim_whitespace "$part")
    [[ -z "$part" ]] && continue
    proxy_endpoints+=("$part")
  done
}

stop_proxy_monitor() {
  if [[ -n "${proxy_monitor_pid:-}" ]]; then
    if kill -0 "$proxy_monitor_pid" >/dev/null 2>&1; then
      kill "$proxy_monitor_pid" >/dev/null 2>&1 || true
    fi
    wait "$proxy_monitor_pid" 2>/dev/null || true
    proxy_monitor_pid=""
  fi
}

check_proxy_health() {
  local host="$1"
  local port="$2"
  if [[ -z "$host" || -z "$port" ]]; then
    return 1
  fi
  if [[ "$port" =~ ^[0-9]+$ ]]; then
    local metrics_port=$((10#$port + 1))
    local metrics_url="http://$host:$metrics_port/api/metrics"
    if timeout "$proxy_health_timeout" curl -fsS --max-time "$proxy_health_timeout" "$metrics_url" >/dev/null 2>&1; then
      return 0
    else
      return 1
    fi
  fi
  timeout "$proxy_health_timeout" bash -lc "exec 3<>/dev/tcp/$host/$port" >/dev/null 2>&1
}

proxy_ready_quick() {
  local endpoint="$1"
  local host="${endpoint%%:*}"
  local port="${endpoint##*:}"
  if [[ -z "$host" || -z "$port" ]]; then
    return 1
  fi

  local min_success=$proxy_health_min_success
  local attempts=0

  while (( attempts < min_success )); do
    if ! check_proxy_health "$host" "$port"; then
      return 1
    fi
    ((attempts++))
    [[ $attempts -lt $min_success ]] && sleep 1
  done

  return 0
}

select_best_proxy() {
  local proxy
  for proxy in "${proxy_endpoints[@]}"; do
    [[ -z "$proxy" ]] && continue
    if proxy_ready_quick "$proxy"; then
      printf '%s' "$proxy"
      return 0
    fi
  done
  printf ''
  return 0
}

start_proxy_monitor() {
  local current_endpoint="$1"
  local miner_pid="$2"

  stop_proxy_monitor

  if [[ -z "$miner_pid" ]]; then
    return
  fi

  (
    local interval=$proxy_health_interval
    local fail_threshold=$proxy_health_failures
    local min_success=$proxy_health_min_success
    [[ $interval -lt 1 ]] && interval=15
    [[ $fail_threshold -lt 0 ]] && fail_threshold=0
    [[ $min_success -lt 1 ]] && min_success=1

    local -a proxies=("${proxy_endpoints[@]}")
    declare -A success_counts=()
    declare -A failure_counts=()

    for proxy in "${proxies[@]}"; do
      success_counts["$proxy"]=0
      failure_counts["$proxy"]=0
    done

    while kill -0 "$miner_pid" >/dev/null 2>&1; do
      local desired_proxy=""
      local desired_index=-1
      local current_index=-1

      for idx in "${!proxies[@]}"; do
        local proxy="${proxies[$idx]}"
        [[ -z "$proxy" ]] && continue

        local host="${proxy%%:*}"
        local port="${proxy##*:}"

        if check_proxy_health "$host" "$port"; then
          success_counts["$proxy"]=$((success_counts["$proxy"] + 1))
          failure_counts["$proxy"]=0
        else
          success_counts["$proxy"]=0
          failure_counts["$proxy"]=$((failure_counts["$proxy"] + 1))
        fi

        if [[ -n "$current_endpoint" && "$proxy" == "$current_endpoint" ]]; then
          current_index=$idx
          if (( fail_threshold > 0 && failure_counts["$proxy"] >= fail_threshold )); then
            echo "WARNING: proxy $proxy failed health checks ($fail_threshold); restarting miner" | tee -a "$LOG_FILE"
            trigger_miner_restart
            exit
          fi
        fi

        if (( success_counts["$proxy"] >= min_success )); then
          if [[ -z "$desired_proxy" ]]; then
            desired_proxy="$proxy"
            desired_index=$idx
          fi
        fi
      done

      if [[ -n "$desired_proxy" ]]; then
        if [[ -z "$current_endpoint" ]]; then
          echo "INFO: proxy $desired_proxy became healthy; restarting miner to switch from direct connection" | tee -a "$LOG_FILE"
          printf '%s\n' "$desired_proxy" > "$pending_proxy_file"
          trigger_miner_restart
          exit
        elif [[ "$desired_proxy" != "$current_endpoint" ]]; then
          if (( current_index == -1 || desired_index < current_index )); then
            echo "INFO: higher-priority proxy $desired_proxy is healthy; restarting miner to switch from $current_endpoint" | tee -a "$LOG_FILE"
            printf '%s\n' "$desired_proxy" > "$pending_proxy_file"
            trigger_miner_restart
            exit
          fi
        fi
      fi

      sleep "$interval"
    done
  ) &

  proxy_monitor_pid=$!
}

if [[ -n "$extra_args" ]]; then
  eval "set -- $extra_args"
  while (($#)); do
    token=$1
    shift

    case $token in
      nvtool)
        if (($# == 0)); then
          miner_extra_args+=("nvtool")
          break
        fi
        opt=$1
        shift

        if [[ $opt == --setcore=* || $opt == --setmem=* || $opt == --setmemoffset=* || $opt == --setcoreoffset=* || $opt == --setclocks=* || $opt == --setpl=* ]]; then
          value=${opt#*=}
          opt=${opt%%=*}
          add_nvtool_cmd "$opt" "$value"
          continue
        fi

        case $opt in
          --setcore|--setmem|--setmemoffset|--setcoreoffset|--setclocks|--setpl)
            if (($# == 0)); then
              echo "WARNING: $opt requires a numeric value" >&2
              continue
            fi
            value=$1
            shift
            add_nvtool_cmd "$opt" "$value"
            continue
            ;;
          *)
            miner_extra_args+=("nvtool" "$opt")
            continue
            ;;
        esac
        ;;
      --setcore|--setmem|--setmemoffset|--setcoreoffset|--setclocks|--setpl)
        if (($# == 0)); then
          echo "WARNING: $token requires a numeric value" >&2
          continue
        fi
        value=$1
        shift
        add_nvtool_cmd "$token" "$value"
        continue
        ;;
      --setcore=*|--setmem=*|--setmemoffset=*|--setcoreoffset=*|--setclocks=*|--setpl=*)
        opt=${token%%=*}
        value=${token#*=}
        add_nvtool_cmd "$opt" "$value"
        continue
        ;;
      -d)
        if (($# == 0)); then
          echo "WARNING: -d requires a value" >&2
        else
          devices_override=$1
          shift
        fi
        continue
        ;;
      -d*)
        value=${token#-d}
        if [[ -z $value ]]; then
          echo "WARNING: -d requires a value" >&2
        else
          devices_override=$value
        fi
        continue
        ;;
      --devices)
        if (($# == 0)); then
          echo "WARNING: --devices requires a value" >&2
        else
          devices_override=$1
          shift
        fi
        continue
        ;;
      --devices=*)
        devices_override=${token#*=}
        continue
        ;;
      --proxy)
        if (($#)); then
          register_proxy_endpoint "$1"
          shift
        else
          echo "WARNING: --proxy requires a value" >&2
        fi
        continue
        ;;
      --proxy=*)
        register_proxy_endpoint "${token#*=}"
        continue
        ;;
      *)
        miner_extra_args+=("$token")
        ;;
    esac
  done
fi

if [[ -n $devices_override ]]; then
  devices=$devices_override
fi

launch_env=()
if [[ -n "$devices" ]]; then
  normalized_devices=${devices//[[:space:]]/}
  if [[ $normalized_devices =~ ^[0-9,]+$ ]]; then
    launch_env+=("CUDA_VISIBLE_DEVICES=$normalized_devices")
    launch_env+=("NVIDIA_VISIBLE_DEVICES=$normalized_devices")
    launch_env+=("GPU_DEVICE_ORDINAL=$normalized_devices")
    launch_env+=("ROCR_VISIBLE_DEVICES=$normalized_devices")
  else
    echo "WARNING: ignoring invalid device list '$devices'" >&2
  fi
fi

if ((${#nvtool_opts[@]})); then
  if command -v nvtool >/dev/null 2>&1; then
    for idx in "${!nvtool_opts[@]}"; do
      opt="${nvtool_opts[$idx]}"
      value="${nvtool_vals[$idx]}"
      echo "Applying nvtool $opt $value"
      if ! nvtool "$opt" "$value"; then
        echo "WARNING: command failed: nvtool $opt $value" >&2
      fi
    done
  else
    echo "WARNING: nvtool not found in PATH, skipping clock adjustments" >&2
  fi
fi

mkdir -p "$(dirname "$LOG_FILE")"
touch "$LOG_FILE"

if ((${#extra_programs[@]})); then
  for program in "${extra_programs[@]}"; do
    start_additional_program "$program"
  done
fi

execute_miner_command() {
  local active_proxy="$1"
  shift
  local run_cmd=("$@")
  local miner_pid=""
  local status=0

  set +e
  if ((${#launch_env[@]})); then
    (
      set -o pipefail
      env "${launch_env[@]}" "${run_cmd[@]}" 2>&1 | tee -a "$LOG_FILE"
    ) &
  else
    (
      set -o pipefail
      "${run_cmd[@]}" 2>&1 | tee -a "$LOG_FILE"
    ) &
  fi
  miner_pid=$!

  start_proxy_monitor "$active_proxy" "$miner_pid"

  wait "$miner_pid"
  status=$?

  stop_proxy_monitor
  set -e
  return $status
}

run_miner_with_proxies() {
  local base_cmd=("$@")
  local last_exit_code=0

  while true; do
    local selected_proxy=""
    local forced_proxy=""
    if [[ -f "$pending_proxy_file" ]]; then
      forced_proxy=$(<"$pending_proxy_file")
      selected_proxy="$forced_proxy"
      rm -f "$pending_proxy_file"
    fi

    if [[ -z "$selected_proxy" ]]; then
      selected_proxy=$(select_best_proxy)
    fi

    local run_cmd=("${base_cmd[@]}")
    if [[ -n "$selected_proxy" ]]; then
      run_cmd+=(--proxy "$selected_proxy")
      echo "INFO: launching prover via proxy $selected_proxy" | tee -a "$LOG_FILE"
    else
      echo "INFO: launching prover without proxy" | tee -a "$LOG_FILE"
    fi

    execute_miner_command "$selected_proxy" "${run_cmd[@]}"
    last_exit_code=$?

    case $last_exit_code in
      0|130|131|137|143)
        return $last_exit_code
        ;;
    esac

    if [[ -z "$selected_proxy" ]]; then
      echo "WARNING: prover exited with code $last_exit_code without proxy" | tee -a "$LOG_FILE"
      sleep 5
    else
      echo "WARNING: prover exited with code $last_exit_code using proxy $selected_proxy" | tee -a "$LOG_FILE"
      sleep 2
    fi
  done
}

cmd=("$BIN_PATH" --pubkey "$pubkey")
[[ -n "$threads_per_card" ]] && cmd+=(--threads-per-card "$threads_per_card")
[[ -n "$rig_name" ]] && cmd+=(--name "$rig_name")
[[ -n "$label" ]] && cmd+=(--label "$label")
[[ -n "$local_ip" ]] && cmd+=(--local-ip "$local_ip")

if ((${#miner_extra_args[@]})); then
  for extra_arg in "${miner_extra_args[@]}"; do
    cmd+=("$extra_arg")
  done
fi

display_cmd=()
if ((${#launch_env[@]})); then
  display_cmd+=(env "${launch_env[@]}")
fi
display_cmd+=("${cmd[@]}")

printf 'Starting %s with command:' "$CUSTOM_NAME"
for arg in "${display_cmd[@]}"; do
  printf ' %q' "$arg"
done
printf '\n'

if (( ${#proxy_endpoints[@]} > 0 )); then
  echo "INFO: proxy priority list: ${proxy_endpoints[*]}" | tee -a "$LOG_FILE"
fi

run_miner_with_proxies "${cmd[@]}"
exit_code=$?

exit $exit_code
